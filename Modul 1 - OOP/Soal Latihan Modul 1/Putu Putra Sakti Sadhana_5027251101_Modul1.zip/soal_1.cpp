#include <iostream>
#define MAX 100
using namespace std;

class Karakter
{
protected:
    string name;
    char tier;
    int hp, attackPower;

public:
    Karakter(string n, char t, int h, int a)
    {
        name = n;
        tier = t;
        hp = h;
        attackPower = a;
    }

    void setTier(char t)
    {
        tier = t;
    }

    char getTier()
    {
        return tier;
    }

    string getName()
    {
        return name;
    }

    virtual void displayInfo()
    {
        cout << "Name: " << name
             << " | Tier: " << tier
             << " | HP: " << hp
             << " | AP: " << attackPower << " | ";
    }

    virtual void useSkill() = 0;

    virtual ~Karakter() {}
};

class Warrior : public Karakter
{
private:
    int stamina;

public:
    Warrior(string n, char t, int h, int a, int s)
        : Karakter(n, t, h, a)
    {
        stamina = s;
    }

    void displayInfo() override
    {
        Karakter::displayInfo();
        cout << "Stamina: " << stamina << endl;
    }

    void useSkill() override
    {
        if (stamina >= 20)
        {
            stamina -= 20;
            cout << name << " uses Sword Slash!" << endl;
        }
        else
        {
            cout << "Stamina " << name << " tidak cukup!" << endl;
        }
    }
};

class Mage : public Karakter
{
private:
    int mana;

public:
    Mage(string n, char t, int h, int a, int m)
        : Karakter(n, t, h, a)
    {
        mana = m;
    }

    void displayInfo() override
    {
        Karakter::displayInfo();
        cout << "Mana: " << mana << endl;
    }

    void useSkill() override
    {
        if (mana >= 30)
        {
            mana -= 30;
            cout << name << " casts Fireball!" << endl;
        }
        else
        {
            cout << "Mana " << name << " tidak cukup!" << endl;
        }
    }
};

Karakter* daftar[MAX];
int jumlah = 0;

void createKarakter()
{
    string name;
    char tier;
    int hp, ap, type;

    cout << "Masukkan nama: ";
    cin.ignore();
    getline(cin, name);

    for (int i = 0; i < jumlah; i++)
    {
        if (daftar[i]->getName() == name)
        {
            cout << "Nama sudah ada!" << endl;
            return;
        }
    }

    cout << "Masukkan tier (A-E): ";
    cin >> tier;

    cout << "Masukkan HP: ";
    cin >> hp;

    cout << "Masukkan attack power: ";
    cin >> ap;

    cout << "Tipe karakter (1 Warrior / 2 Mage): ";
    cin >> type;

    if (type == 1)
    {
        int stamina;
        cout << "Masukkan stamina: ";
        cin >> stamina;
        daftar[jumlah++] = new Warrior(name, tier, hp, ap, stamina);
    }
    else if (type == 2)
    {
        int mana;
        cout << "Masukkan mana: ";
        cin >> mana;
        daftar[jumlah++] = new Mage(name, tier, hp, ap, mana);
    }
    else
    {
        cout << "Tipe tidak valid!" << endl;
    }
}

void showKarakter()
{
    if (jumlah == 0)
    {
        cout << "Belum ada karakter!" << endl;
        return;
    }

    for (int i = 0; i < jumlah; i++)
    {
        cout << i + 1 << ". ";
        daftar[i]->displayInfo();
    }
}

void promote()
{
    string name;

    cout << "Masukkan nama karakter: ";
    cin.ignore();
    getline(cin, name);

    for (int i = 0; i < jumlah; i++)
    {
        if (daftar[i]->getName() == name)
        {
            char tier = daftar[i]->getTier();

            if (tier == 'A')
            {
                cout << "Sudah tier tertinggi!" << endl;
                return;
            }

            daftar[i]->setTier(tier - 1);

            cout << "Karakter berhasil dipromote ke tier "
                 << daftar[i]->getTier() << endl;
            return;
        }
    }

    cout << "Karakter tidak ditemukan!" << endl;
}

void deleteKarakter()
{
    string name;

    cout << "Masukkan nama karakter: ";
    cin.ignore();
    getline(cin, name);

    for (int i = 0; i < jumlah; i++)
    {
        if (daftar[i]->getName() == name)
        {
            delete daftar[i];

            for (int j = i; j < jumlah - 1; j++)
            {
                daftar[j] = daftar[j + 1];
            }

            jumlah--;

            cout << "Karakter berhasil dihapus!" << endl;
            return;
        }
    }

    cout << "Karakter tidak ditemukan!" << endl;
}

void useSkill()
{
    string name;

    cout << "Masukkan nama karakter: ";
    cin.ignore();
    getline(cin, name);

    for (int i = 0; i < jumlah; i++)
    {
        if (daftar[i]->getName() == name)
        {
            daftar[i]->useSkill();
            return;
        }
    }

    cout << "Karakter tidak ditemukan!" << endl;
}

void menu()
{
    cout << "\n=== Game Karakter ===\n";
    cout << "1. Create Karakter\n";
    cout << "2. Lihat Karakter\n";
    cout << "3. Promote Karakter\n";
    cout << "4. Hapus Karakter\n";
    cout << "5. Gunakan Skill\n";
    cout << "6. Exit\n";
}

int main()
{
    int choice;

    while (true)
    {
        menu();
        cout << "Pilihan: ";
        cin >> choice;

        switch (choice)
        {
        case 1:
            createKarakter();
            break;
        case 2:
            showKarakter();
            break;
        case 3:
            promote();
            break;
        case 4:
            deleteKarakter();
            break;
        case 5:
            useSkill();
            break;
        case 6:
            cout << "Program selesai." << endl;
            return 0;
        default:
            cout << "Pilihan tidak valid!" << endl;
        }
    }
}
